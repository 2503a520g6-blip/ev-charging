"""EV Charging Station Allocation System using Mutex and Counting Semaphore."""
import threading
import time
import random
from datetime import datetime

TOTAL_SLOTS = 3
TOTAL_EVS = 8
CHARGING_TIME = (2, 5)

# Counting semaphore: maximum 3 EVs may charge simultaneously.
charging_slots = threading.Semaphore(TOTAL_SLOTS)

# Mutex: protects shared slot data and the allocation log.
station_mutex = threading.Lock()
slots = [None] * TOTAL_SLOTS
allocation_log = []


def log(message):
    with station_mutex:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}", flush=True)


def allocate_slot(ev_id):
    with station_mutex:
        for index, current_ev in enumerate(slots):
            if current_ev is None:
                slots[index] = ev_id
                allocation_log.append(
                    f"{ev_id} allocated Slot {index + 1} "
                    f"at {datetime.now().strftime('%H:%M:%S')}"
                )
                return index
    return None


def release_slot(slot_index, ev_id):
    with station_mutex:
        slots[slot_index] = None
        allocation_log.append(
            f"{ev_id} released Slot {slot_index + 1} "
            f"at {datetime.now().strftime('%H:%M:%S')}"
        )


def show_status():
    with station_mutex:
        print("\\n------ CHARGING STATION STATUS ------")
        for index, ev in enumerate(slots, start=1):
            print(f"Slot {index}: {'Occupied by ' + ev if ev else 'Available'}")
        print("-------------------------------------\\n", flush=True)


def ev_process(ev_id):
    log(f"{ev_id} is waiting for a charging slot.")

    # Semaphore acquire: wait if all charging permits are in use.
    charging_slots.acquire()
    log(f"{ev_id} received permission to charge.")

    slot_index = allocate_slot(ev_id)
    if slot_index is None:
        charging_slots.release()
        log(f"{ev_id}: allocation failed.")
        return

    log(f"{ev_id} started charging in Slot {slot_index + 1}.")
    show_status()

    duration = random.randint(*CHARGING_TIME)
    time.sleep(duration)

    log(f"{ev_id} completed charging after {duration} seconds.")
    release_slot(slot_index, ev_id)

    # Semaphore release: allow a waiting EV to use the free capacity.
    charging_slots.release()
    log(f"{ev_id} released Slot {slot_index + 1}.")
    show_status()


def main():
    print("=" * 52)
    print("       EV CHARGING STATION ALLOCATION SYSTEM")
    print("=" * 52)
    print(f"Charging slots: {TOTAL_SLOTS} | EV requests: {TOTAL_EVS}")
    print("OS concepts: Threads, Mutex, Counting Semaphore\\n")

    threads = []
    for number in range(1, TOTAL_EVS + 1):
        thread = threading.Thread(target=ev_process, args=(f"EV-{number}",))
        threads.append(thread)
        thread.start()
        time.sleep(0.3)

    for thread in threads:
        thread.join()

    print("\\n=============== FINAL REPORT ===============")
    with station_mutex:
        for entry in allocation_log:
            print(entry)
        print("\\nFinal slot status:")
        for index, ev in enumerate(slots, start=1):
            print(f"Slot {index}: {'Available' if ev is None else ev}")
    print("All EV requests have been processed.")
    print("=" * 48)


if __name__ == "__main__":
    main()
