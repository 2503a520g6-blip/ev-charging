# EV Charging Station Allocation System

## Problem statement
When many electric vehicles (EVs) request charging at the same time, a station must allocate its limited charging slots safely. The system must prevent two EVs from using the same slot and must not allow more EVs to charge simultaneously than the station can support.

## Objectives
- Allocate limited charging slots to EVs.
- Use a counting semaphore to limit simultaneous charging.
- Use a mutex to protect shared slot information.
- Demonstrate threads, synchronization and safe resource sharing.

## Requirements
- Python 3.9 or later
- VS Code or another Python IDE
- No external packages required

## Files
- `main.py` — complete runnable program
- `README.md` — project explanation and run instructions

## OS concepts used

### Threads
Each EV is represented by a separate thread. Each thread requests a charging slot.

### Counting semaphore
`threading.Semaphore(3)` provides three permits. At most three EV threads can charge at the same time.
- `acquire()` requests a permit and waits if none is available.
- `release()` returns a permit when charging is complete.

### Mutex
`threading.Lock()` protects the shared `slots` list and allocation log.
The `with station_mutex:` block ensures that only one thread at a time updates or reads this shared information.

**Important difference:** The semaphore limits the number of EVs charging at once. The mutex protects shared data from simultaneous updates.

## How to run in VS Code
1. Extract the ZIP file.
2. Open VS Code.
3. Select **File → Open Folder** and choose this project folder.
4. Open `main.py`.
5. Select **Terminal → New Terminal**.
6. Run:

```bash
python main.py
```

If that command does not work on Windows, try:

```bash
py main.py
```

## Expected behaviour
The program creates 8 EV threads and 3 charging slots. If all three slots are occupied, other EV threads wait. When an EV finishes, it releases its slot and semaphore permit, allowing another waiting EV to charge.

The exact order and charging duration vary on each run because thread scheduling is controlled by the operating system.

## Conclusion
This project demonstrates how OS synchronization manages limited shared resources. The counting semaphore ensures that no more than three EVs charge simultaneously, while the mutex protects shared allocation data from race conditions.
